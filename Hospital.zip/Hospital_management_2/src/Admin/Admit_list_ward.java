package Admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;

public class Admit_list_ward {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_3;
	private JTable table;
	private JTable table_1;
	private JTextField textField_2;
	private JComboBox comboBox_1;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admit_list_ward window = new Admit_list_ward();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Admit_list_ward() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 777, 564);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(182, 124, 243, 41);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(182, 176, 243, 41);
		frame.getContentPane().add(textField_1);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(182, 280, 243, 41);
		frame.getContentPane().add(textField_3);
		
		JLabel lblNewLabel = new JLabel("Patient ID*");
		lblNewLabel.setBounds(46, 124, 111, 41);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblWardNo = new JLabel("Ward No*");
		lblWardNo.setBounds(46, 176, 117, 41);
		frame.getContentPane().add(lblWardNo);
		
		JLabel lblDateOfAdmit = new JLabel("Date of Admit*");
		lblDateOfAdmit.setBounds(46, 280, 90, 41);
		frame.getContentPane().add(lblDateOfAdmit);
		
		JButton btnAdmitInWard = new JButton("Admit in Ward");
		btnAdmitInWard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt= (PreparedStatement) connection.prepareStatement("INSERT INTO patient_admit_ward(Patient_ID,ward_no,Bed_no,Date_of_admit)VALUES(?,?,?,?)");
					stmnt.setString(1,textField.getText());
					stmnt.setString(2,textField_1.getText());
					stmnt.setString(3,textField_5.getText());
					stmnt.setString(4,textField_3.getText());
					//stmnt.setString(5,textField_4.getText());
					
					
					
					int rs= stmnt.executeUpdate();
						
					
						if(rs>0) {
							JOptionPane.showMessageDialog(null,"Successfully Addmitted");
							//label_1.setText("Successfully signed up. Login for go next step");
							
						}
						else {
							JOptionPane.showMessageDialog(null,"Failed");
						}
						
						
						stmnt.close();
						connection.close();
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
				
				
					try {
						Class.forName("com.mysql.jdbc.Driver");
						Connection connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
						Statement st= connection.createStatement();
						String query= "UPDATE `ward` SET `Status`='full' WHERE `Ward_no`="+textField_1.getText()+" and `Bed_no`="+textField_5.getText()+"";
						if((st.executeUpdate(query))==1) {
							
							JOptionPane.showMessageDialog(null,"Successful");
							
							
						}
							
						}
					 catch (ClassNotFoundException f) {
						// TODO Auto-generated catch block
						f.printStackTrace();
					} catch (SQLException f) {
						// TODO Auto-generated catch block
						f.printStackTrace();
					}
				textField.setText(null);
				textField_1.setText(null);
				textField_2.setText(null);
				textField_3.setText(null);
				//textField_4.setText(null);
				textField_5.setText(null);
			}
		});
		btnAdmitInWard.setBounds(182, 333, 159, 23);
		frame.getContentPane().add(btnAdmitInWard);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent arg0) {
try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					con.createStatement();
					
					
					PreparedStatement pst= con.prepareStatement("select * from ward");
					ResultSet rs=pst.executeQuery("select * from ward");
					
					ResultSetMetaData rsdata= rs.getMetaData();
					
					int columns= rsdata.getColumnCount();
					DefaultTableModel dtm= new DefaultTableModel();
					Vector columns_name= new Vector();
					Vector data_rows= new Vector();
					
					for(int i=1; i<=columns;i++) {
						columns_name.addElement(rsdata.getColumnName(i));
						
					}
					dtm.setColumnIdentifiers(columns_name);
					while(rs.next()) {
						data_rows= new Vector();
						for(int j=1;j<=columns;j++) {
							data_rows.addElement(rs.getString(j));
							
						}
						dtm.addRow(data_rows);
					}
					table.setModel(dtm);
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		scrollPane.setBounds(492, 333, 243, 181);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i= table.getSelectedRow();
				TableModel model = table.getModel();
				textField_1.setText(model.getValueAt(i,0).toString());
				textField_5.setText(model.getValueAt(i,1).toString());
			}
		});
		scrollPane.setViewportView(table);
		
		JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					con.createStatement();
					
					
					PreparedStatement pst= con.prepareStatement("select * from ward where Status='"+comboBox.getSelectedItem().toString()+"'");
					ResultSet rs=pst.executeQuery("select * from ward where Status='"+comboBox.getSelectedItem().toString()+"'");
					
					ResultSetMetaData rsdata= rs.getMetaData();
					
					int columns= rsdata.getColumnCount();
					DefaultTableModel dtm= new DefaultTableModel();
					Vector columns_name= new Vector();
					Vector data_rows= new Vector();
					
					for(int i=1; i<=columns;i++) {
						columns_name.addElement(rsdata.getColumnName(i));
						
					}
					dtm.setColumnIdentifiers(columns_name);
					while(rs.next()) {
						data_rows= new Vector();
						for(int j=1;j<=columns;j++) {
							data_rows.addElement(rs.getString(j));
							
						}
						dtm.addRow(data_rows);
					}
					table.setModel(dtm);
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
				
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"full", "empty"}));
		comboBox.setBounds(635, 296, 100, 34);
		frame.getContentPane().add(comboBox);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(492, 104, 243, 181);
		frame.getContentPane().add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int i= table_1.getSelectedRow();
				TableModel model = table_1.getModel();
				textField.setText(model.getValueAt(i,0).toString());
				
			}
		});
		scrollPane_1.setViewportView(table_1);
		
		textField_2 = new JTextField();
		textField_2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					con.createStatement();
					
					
					PreparedStatement pst= con.prepareStatement("select Patient_ID,Name from patient where Name='"+textField_2.getText()+"' or Patient_ID='"+textField_2.getText()+"'");
					ResultSet rs=pst.executeQuery("select Patient_ID,Name from patient where Name='"+textField_2.getText()+"' or Patient_ID='"+textField_2.getText()+"'");
					
					ResultSetMetaData rsdata= rs.getMetaData();
					
					int columns= rsdata.getColumnCount();
					DefaultTableModel dtm= new DefaultTableModel();
					Vector columns_name= new Vector();
					Vector data_rows= new Vector();
					
					for(int i=1; i<=columns;i++) {
						columns_name.addElement(rsdata.getColumnName(i));
						
					}
					dtm.setColumnIdentifiers(columns_name);
					while(rs.next()) {
						data_rows= new Vector();
						for(int j=1;j<=columns;j++) {
							data_rows.addElement(rs.getString(j));
							
						}
						dtm.addRow(data_rows);
					}
					table_1.setModel(dtm);
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		textField_2.setColumns(10);
		textField_2.setBounds(618, 62, 117, 31);
		frame.getContentPane().add(textField_2);
		
		JLabel lblSearchPatient = new JLabel("Search Patient");
		lblSearchPatient.setBounds(492, 63, 116, 28);
		frame.getContentPane().add(lblSearchPatient);
		
		JLabel lblCheckAvailableWard = new JLabel("Check Available Ward");
		lblCheckAvailableWard.setBounds(492, 299, 133, 28);
		frame.getContentPane().add(lblCheckAvailableWard);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(182, 228, 243, 41);
		frame.getContentPane().add(textField_5);
		
		JLabel lblBedNo = new JLabel("Bed No*");
		lblBedNo.setBounds(46, 228, 117, 41);
		frame.getContentPane().add(lblBedNo);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Admit_list window = new Admit_list();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnBack.setBounds(10, 491, 89, 23);
		frame.getContentPane().add(btnBack);
		
		JLabel lblWard = new JLabel("Ward");
		lblWard.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblWard.setBounds(25, 30, 252, 26);
		frame.getContentPane().add(lblWard);
	}
}
