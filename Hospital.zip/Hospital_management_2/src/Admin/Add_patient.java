package Admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;

public class Add_patient {

	private JFrame frame;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JComboBox  comboBox; 

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_patient window = new Add_patient();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Add_patient() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 513, 562);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(135, 162, 222, 33);
		frame.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(135, 206, 222, 33);
		frame.getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(135, 250, 222, 33);
		frame.getContentPane().add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(135, 294, 222, 33);
		frame.getContentPane().add(textField_4);
		
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female"}));
		comboBox.setBounds(135, 338, 150, 33);
		frame.getContentPane().add(comboBox);
		
		JLabel lblName = new JLabel("Name*");
		lblName.setBounds(25, 166, 91, 24);
		frame.getContentPane().add(lblName);
		
		JLabel lblAddress = new JLabel("Address*");
		lblAddress.setBounds(25, 210, 91, 24);
		frame.getContentPane().add(lblAddress);
		
		JLabel lblPhoneNo = new JLabel("Phone No.*");
		lblPhoneNo.setBounds(25, 254, 91, 24);
		frame.getContentPane().add(lblPhoneNo);
		
		JLabel lblAge = new JLabel("Age*");
		lblAge.setBounds(25, 298, 91, 24);
		frame.getContentPane().add(lblAge);
		
		JLabel lblSex = new JLabel("Sex*");
		lblSex.setBounds(25, 342, 91, 24);
		frame.getContentPane().add(lblSex);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt= (PreparedStatement) connection.prepareStatement("INSERT INTO patient(Name,Address,Phone_no,Sex,Age)VALUES(?,?,?,?,?)");
					//stmnt.setString(1,textField.getText());
					stmnt.setString(1,textField_1.getText());
					stmnt.setString(2,textField_2.getText());
					stmnt.setString(3,textField_3.getText());
					stmnt.setString(4,comboBox.getSelectedItem().toString());
					stmnt.setString(5,textField_4.getText());
					
					
					int rs= stmnt.executeUpdate();
						
					
						if(rs>0) {
							JOptionPane.showMessageDialog(null,"Successfully Added");
							//label_1.setText("Successfully signed up. Login for go next step");
						}
						else {
							JOptionPane.showMessageDialog(null,"Failed");
						}
						
						
						stmnt.close();
						connection.close();
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					JOptionPane.showMessageDialog(null,"Something Went Wrong");
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					JOptionPane.showMessageDialog(null,"Something Went Wrong");
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
				//textField.setText(null);
				textField_1.setText(null);
				textField_2.setText(null);
				textField_3.setText(null);
				textField_4.setText(null);
			}
		});
		btnNewButton.setBounds(135, 402, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Admin_option window = new Admin_option();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnBack.setBounds(10, 489, 89, 23);
		frame.getContentPane().add(btnBack);
		
		JLabel lblAddPatient = new JLabel("Add Patient");
		lblAddPatient.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAddPatient.setBounds(25, 57, 252, 26);
		frame.getContentPane().add(lblAddPatient);
	}
}
