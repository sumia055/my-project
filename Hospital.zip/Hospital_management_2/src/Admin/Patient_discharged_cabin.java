package Admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Patient_discharged_cabin {

	private JFrame frame;
	private JTable table;
	private JTextField textField;
	private JTextField textField_1;
	private JLabel lblDischargedDate;
	private JTextField textField_2;
	private JButton btnBack;
	private JLabel lblCabin;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Patient_discharged_cabin window = new Patient_discharged_cabin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Patient_discharged_cabin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 736, 485);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(336, 126, 354, 174);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i= table.getSelectedRow();
				TableModel model = table.getModel();
				textField_2.setText(model.getValueAt(i,0).toString());
			}
		});
		scrollPane.setViewportView(table);
		
		textField = new JTextField();
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					con.createStatement();
					
					
					PreparedStatement pst= con.prepareStatement("select * from patient_admit_cabin where Patient_ID='"+textField.getText()+"'");
					ResultSet rs=pst.executeQuery("select * from patient_admit_cabin where Patient_ID='"+textField.getText()+"'");
					
					ResultSetMetaData rsdata= rs.getMetaData();
					
					int columns= rsdata.getColumnCount();
					DefaultTableModel dtm= new DefaultTableModel();
					Vector columns_name= new Vector();
					Vector data_rows= new Vector();
					
					for(int i=1; i<columns;i++) {
						columns_name.addElement(rsdata.getColumnName(i));
						
					}
					dtm.setColumnIdentifiers(columns_name);
					while(rs.next()) {
						data_rows= new Vector();
						for(int j=1;j<columns;j++) {
							data_rows.addElement(rs.getString(j));
							
						}
						dtm.addRow(data_rows);
					}
					table.setModel(dtm);
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		textField.setBounds(511, 88, 178, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblSearchAdmitList = new JLabel("Search Admit List");
		lblSearchAdmitList.setBounds(358, 88, 143, 26);
		frame.getContentPane().add(lblSearchAdmitList);
		
		textField_1 = new JTextField();
		textField_1.setBounds(148, 191, 178, 33);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		lblDischargedDate = new JLabel("Discharged Date");
		lblDischargedDate.setBounds(10, 190, 120, 35);
		frame.getContentPane().add(lblDischargedDate);
		
		JButton btnDischarge = new JButton("Discharge");
		btnDischarge.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					Statement st= connection.createStatement();
					String query= "UPDATE `patient_admit_cabin` SET `Date_of_discharged`='"+textField_1.getText()+"' WHERE `Patient_ID`="+textField_2.getText()+"";
					if((st.executeUpdate(query))==1) {
						
						JOptionPane.showMessageDialog(null,"Successful");
						
						
					}
						
					}
				 catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			textField.setText(null);
			textField_1.setText(null);
			textField_2.setText(null);
			}
		});
		btnDischarge.setBounds(148, 266, 100, 23);
		frame.getContentPane().add(btnDischarge);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(148, 148, 178, 33);
		frame.getContentPane().add(textField_2);
		
		JLabel lblPatientId = new JLabel("Patient ID");
		lblPatientId.setBounds(10, 147, 120, 35);
		frame.getContentPane().add(lblPatientId);
		
		btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Discharge_option window = new Discharge_option();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnBack.setBounds(10, 412, 89, 23);
		frame.getContentPane().add(btnBack);
		
		lblCabin = new JLabel("Cabin");
		lblCabin.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCabin.setBounds(10, 11, 252, 26);
		frame.getContentPane().add(lblCabin);
	}
}
