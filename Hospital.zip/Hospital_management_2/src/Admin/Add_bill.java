package Admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;



import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;

public class Add_bill {

	private JFrame frame;
	private JTextField textField_2;
	private JTextField textField_4;
	private JLabel lblQuantity;
	private JLabel lblPatientId;
	private JButton btnSell;
	private JTextField textField_5;
	private JLabel lblTotalPrice;
	private JTextField textField_6;
	private JTable table_1;
	private JButton btnBack;
	private JLabel lblMedicineShop;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_bill window = new Add_bill();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Add_bill() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 596, 481);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(130, 217, 163, 32);
		frame.getContentPane().add(textField_2);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(130, 131, 163, 32);
		frame.getContentPane().add(textField_4);
		
		lblQuantity = new JLabel("Price*");
		lblQuantity.setBounds(24, 218, 138, 30);
		frame.getContentPane().add(lblQuantity);
		
		lblPatientId = new JLabel("Patient ID*");
		lblPatientId.setBounds(24, 132, 138, 30);
		frame.getContentPane().add(lblPatientId);
		
		btnSell = new JButton("Sell");
		btnSell.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//int one= Integer.parseInt(textField_2.getText());
				//int two= Integer.parseInt(textField_3.getText());
				//String Ans=String.valueOf(one*two);
				//textField_5.setText(Ans);
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt= (PreparedStatement) connection.prepareStatement("INSERT INTO bill(Patient_ID,Description,Cost)VALUES(?,?,?)");
					//stmnt.setString(1,textField_1.getText());
					stmnt.setString(1,textField_4.getText());
					//stmnt.setString(3,textField_3.getText());
					stmnt.setString(2,textField_5.getText());
					stmnt.setString(3,textField_2.getText());
					
					
					
					int rs= stmnt.executeUpdate();
						
					
						if(rs>0) {
							JOptionPane.showMessageDialog(null,"Successfully Added");
							//label_1.setText("Successfully signed up. Login for go next step");
						}
						else {
							JOptionPane.showMessageDialog(null,"Failed");
						}
						
						
						stmnt.close();
						connection.close();
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					JOptionPane.showMessageDialog(null,"Something Went Wrong");
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					JOptionPane.showMessageDialog(null,"Something Went Wrong");
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
				//textField.setText(null);
				//textField_1.setText(null);
				textField_2.setText(null);
				//textField_3.setText(null);
				textField_4.setText(null);
				textField_5.setText(null);
		
				
			}
		});
		btnSell.setBounds(130, 281, 89, 23);
		frame.getContentPane().add(btnSell);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(130, 174, 163, 32);
		frame.getContentPane().add(textField_5);
		
		lblTotalPrice = new JLabel("Description*");
		lblTotalPrice.setBounds(24, 174, 138, 30);
		frame.getContentPane().add(lblTotalPrice);
		
		textField_6 = new JTextField();
		textField_6.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					con.createStatement();
					
					
					PreparedStatement pst= con.prepareStatement("select Patient_ID,Name from patient where Patient_ID or Name ='"+textField_6.getText()+"'");
					ResultSet rs=pst.executeQuery("select Patient_ID,Name from patient where Patient_ID or Name='"+textField_6.getText()+"'");
					
					ResultSetMetaData rsdata= rs.getMetaData();
					
					int columns= rsdata.getColumnCount();
					DefaultTableModel dtm= new DefaultTableModel();
					Vector columns_name= new Vector();
					Vector data_rows= new Vector();
					
					for(int i=1; i<=columns;i++) {
						columns_name.addElement(rsdata.getColumnName(i));
						
					}
					dtm.setColumnIdentifiers(columns_name);
					while(rs.next()) {
						data_rows= new Vector();
						for(int j=1;j<=columns;j++) {
							data_rows.addElement(rs.getString(j));
							
						}
						dtm.addRow(data_rows);
					}
					table_1.setModel(dtm);
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		textField_6.setColumns(10);
		textField_6.setBounds(393, 100, 138, 32);
		frame.getContentPane().add(textField_6);
		
		JLabel lblSearchPatient = new JLabel("Search Patient");
		lblSearchPatient.setBounds(303, 102, 120, 30);
		frame.getContentPane().add(lblSearchPatient);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(303, 131, 228, 173);
		frame.getContentPane().add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int i= table_1.getSelectedRow();
				TableModel model = table_1.getModel();
				textField_4.setText(model.getValueAt(i,0).toString());
				//textField_2.setText(model.getValueAt(i,1).toString());
			}
		});
		scrollPane_1.setViewportView(table_1);
		
		btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnBack.setBounds(10, 408, 89, 23);
		frame.getContentPane().add(btnBack);
		
		lblMedicineShop = new JLabel("Add Bill");
		lblMedicineShop.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblMedicineShop.setBounds(24, 29, 252, 26);
		frame.getContentPane().add(lblMedicineShop);
	}
}
