package Admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class total_billing {

	private JFrame frame;
	private JTable table;
	private JTextField textField;
	private JTextField textField_2;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JButton btnAdd;
	private JLabel lblBill;
	private JButton btnBack;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					total_billing window = new total_billing();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public total_billing() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 630, 507);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(237, 161, 354, 190);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int i= table.getSelectedRow();
				TableModel model = table.getModel();
				textField_2.setText(model.getValueAt(i,0).toString());
				textField_4.setText(model.getValueAt(i,1).toString());
				textField_5.setText(model.getValueAt(i,2).toString());
			}
		});
		scrollPane.setViewportView(table);
		
		textField = new JTextField();
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					con.createStatement();
					
					
					PreparedStatement pst= con.prepareStatement("select * from bill where Patient_ID='"+textField.getText()+"'");
					ResultSet rs=pst.executeQuery("select * from bill where Patient_ID='"+textField.getText()+"'");
					
					ResultSetMetaData rsdata= rs.getMetaData();
					
					int columns= rsdata.getColumnCount();
					DefaultTableModel dtm= new DefaultTableModel();
					Vector columns_name= new Vector();
					Vector data_rows= new Vector();
					
					for(int i=1; i<=columns;i++) {
						columns_name.addElement(rsdata.getColumnName(i));
						
					}
					dtm.setColumnIdentifiers(columns_name);
					while(rs.next()) {
						data_rows= new Vector();
						for(int j=1;j<=columns;j++) {
							data_rows.addElement(rs.getString(j));
							
						}
						dtm.addRow(data_rows);
					}
					table.setModel(dtm);
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		textField.setBounds(398, 122, 193, 28);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblSearchPatient = new JLabel("Search Patient");
		lblSearchPatient.setBounds(304, 122, 94, 28);
		frame.getContentPane().add(lblSearchPatient);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(82, 170, 150, 28);
		frame.getContentPane().add(textField_2);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(82, 209, 150, 28);
		frame.getContentPane().add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(82, 248, 150, 28);
		frame.getContentPane().add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(82, 287, 150, 28);
		frame.getContentPane().add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(82, 326, 150, 28);
		frame.getContentPane().add(textField_7);
		
		JLabel lblNewLabel = new JLabel("Patient ID*");
		lblNewLabel.setBounds(10, 170, 110, 28);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblDisease = new JLabel("Disease*");
		lblDisease.setBounds(10, 209, 110, 28);
		frame.getContentPane().add(lblDisease);
		
		JLabel lblCost = new JLabel("Cost*");
		lblCost.setBounds(10, 248, 110, 28);
		frame.getContentPane().add(lblCost);
		
		JLabel lblTotalPay = new JLabel("Total Pay*");
		lblTotalPay.setBounds(10, 287, 110, 28);
		frame.getContentPane().add(lblTotalPay);
		
		JLabel lblTotalDue = new JLabel("Total Due*");
		lblTotalDue.setBounds(10, 326, 110, 28);
		frame.getContentPane().add(lblTotalDue);
		
		btnAdd = new JButton("print");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int one= Integer.parseInt(textField_5.getText());
				int two= Integer.parseInt(textField_6.getText());
				String Ans=String.valueOf(one-two);
				textField_7.setText(Ans);
				
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt= (PreparedStatement) connection.prepareStatement("INSERT INTO treatment(Patient_ID,Doctor_ID,Disease,Cost,Total_pay,Due)VALUES(?,?,?,?,?,?)");
					stmnt.setString(1,textField_2.getText());
					//stmnt.setString(2,textField_3.getText());
					stmnt.setString(2,textField_4.getText());
					stmnt.setString(3,textField_5.getText());
					stmnt.setString(4,textField_6.getText());
					stmnt.setString(5,textField_7.getText());
					
					
					
					
					int rs= stmnt.executeUpdate();
						
					
						if(rs>0) {
							JOptionPane.showMessageDialog(null,"Successfully Added");
							//label_1.setText("Successfully signed up. Login for go next step");
						}
						else {
							JOptionPane.showMessageDialog(null,"Failed");
						}
						
						
						stmnt.close();
						connection.close();
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					JOptionPane.showMessageDialog(null,"Something Went Wrong");
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					JOptionPane.showMessageDialog(null,"Something Went Wrong");
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
				textField.setText(null);
				//textField_1.setText(null);
				textField_2.setText(null);
				//textField_3.setText(null);
				textField_4.setText(null);
				textField_5.setText(null);
				textField_6.setText(null);
				textField_7.setText(null);
				
			}
		});
		btnAdd.setBounds(82, 365, 89, 23);
		frame.getContentPane().add(btnAdd);
		
		lblBill = new JLabel("Bill");
		lblBill.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblBill.setBounds(10, 28, 272, 38);
		frame.getContentPane().add(lblBill);
		
		btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnBack.setBounds(10, 433, 89, 23);
		frame.getContentPane().add(btnBack);
	}
}
