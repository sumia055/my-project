package Admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Discharge_option {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Discharge_option window = new Discharge_option();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Discharge_option() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 269, 299);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblDischargeOption = new JLabel("Discharge Option");
		lblDischargeOption.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDischargeOption.setBounds(10, 23, 195, 31);
		frame.getContentPane().add(lblDischargeOption);
		
		JButton button = new JButton("Ward");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient_discharged_ward window = new Patient_discharged_ward();
				frame.setVisible(false);
				window.main(null);
			}
		});
		button.setBounds(33, 98, 89, 41);
		frame.getContentPane().add(button);
		
		JButton button_1 = new JButton("Cabin");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient_discharged_cabin window = new Patient_discharged_cabin();
				frame.setVisible(false);
				window.main(null);
			}
		});
		button_1.setBounds(33, 139, 89, 41);
		frame.getContentPane().add(button_1);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Admin_option window = new Admin_option();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnBack.setBounds(10, 226, 89, 23);
		frame.getContentPane().add(btnBack);
	}

}
