package Admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;

public class Admin_option {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin_option window = new Admin_option();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Admin_option() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 537, 551);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnAddPatientRecord = new JButton("Add Patient Record");
		btnAddPatientRecord.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Add_patient window = new Add_patient();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnAddPatientRecord.setBounds(61, 138, 162, 28);
		frame.getContentPane().add(btnAddPatientRecord);
		
		JButton btnAddAppoinment = new JButton("Add Appoinment");
		btnAddAppoinment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Add_appoinment window = new Add_appoinment();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnAddAppoinment.setBounds(61, 177, 162, 28);
		frame.getContentPane().add(btnAddAppoinment);
		
		JButton btnAllAppoinments = new JButton("All Appoinments");
		btnAllAppoinments.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				All_appoinment window = new All_appoinment();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnAllAppoinments.setBounds(61, 216, 162, 28);
		frame.getContentPane().add(btnAllAppoinments);
		
		JButton btnAdmitPatient = new JButton("Admit Patient");
		btnAdmitPatient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Admit_list window = new Admit_list();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnAdmitPatient.setBounds(61, 255, 162, 28);
		frame.getContentPane().add(btnAdmitPatient);
		
		JButton btnDischargePatient = new JButton("Discharge Patient");
		btnDischargePatient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Discharge_option window = new Discharge_option();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnDischargePatient.setBounds(61, 294, 162, 28);
		frame.getContentPane().add(btnDischargePatient);
		
		JButton btnSeeDoctorsRoom = new JButton("See Doctor's Info");
		btnSeeDoctorsRoom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Doctor_room window = new Doctor_room();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnSeeDoctorsRoom.setBounds(61, 333, 162, 28);
		frame.getContentPane().add(btnSeeDoctorsRoom);
		
		JLabel lblOption = new JLabel("Option");
		lblOption.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblOption.setBounds(22, 32, 162, 37);
		frame.getContentPane().add(lblOption);
		
		JButton btnTotalBilling = new JButton("Total Billing");
		btnTotalBilling.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				total_billing window = new total_billing();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnTotalBilling.setBounds(61, 372, 162, 28);
		frame.getContentPane().add(btnTotalBilling);
		
		JButton btnLogOut = new JButton("Log Out");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login window = new Login();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnLogOut.setBounds(61, 411, 162, 28);
		frame.getContentPane().add(btnLogOut);
	}
}
