package Admin;
import java.awt.EventQueue;

import javax.swing.JFrame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Table_create {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Table_create window = new Table_create();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Table_create() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 570, 390);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblTableCreate = new JLabel("Table Create");
		lblTableCreate.setBounds(34, 23, 175, 23);
		frame.getContentPane().add(lblTableCreate);
		
		JButton btnDoctor_1 = new JButton("Doctor");
		btnDoctor_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection1= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt1= (PreparedStatement) connection1.prepareStatement("CREATE TABLE doctor(Doctor_ID int primary key AUTO_INCREMENT,Name varchar(20) not null,Address varchar(20) not null,Phone_no varchar(20) not null,Sex varchar(20) not null,Time_Sedule varchar(20) not null,Designation varchar(20) not null,Type varchar(20) not null)");
					
					
					
					int rs1= stmnt1.executeUpdate();
						
					
						if(rs1>0) {
							//JOptionPane.showMessageDialog(null,"Successful");
							//label_1.setText("Successfully signed up. Login for go next step");
							
						}
						else {
							JOptionPane.showMessageDialog(null,"Successful");
						}
						
						
						
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		btnDoctor_1.setBounds(34, 251, 130, 23);
		frame.getContentPane().add(btnDoctor_1);
		
		JButton btnPatient = new JButton("Patient");
		btnPatient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection1= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt1= (PreparedStatement) connection1.prepareStatement("CREATE TABLE patient(Patient_ID int primary key AUTO_INCREMENT,Name varchar(20) not null,Address varchar(20) not null,Phone_no varchar(20) not null,Sex varchar(20) not null,Age int not null)");
					
					
					
					int rs1= stmnt1.executeUpdate();
						
					
						if(rs1>0) {
							//JOptionPane.showMessageDialog(null,"Successful");
							//label_1.setText("Successfully signed up. Login for go next step");
							
						}
						else {
							JOptionPane.showMessageDialog(null,"Successful");
						}
						
						
						
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		btnPatient.setBounds(34, 285, 130, 23);
		frame.getContentPane().add(btnPatient);
		
		JButton btnPatientAdmit = new JButton("Patient Admit Ward");
		btnPatientAdmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection1= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt1= (PreparedStatement) connection1.prepareStatement("CREATE TABLE patient_admit_ward(Patient_ID int primary key AUTO_INCREMENT,ward_no int not null,Bed_no int not null,Date_of_admit varchar(20) not null,Date_of_discharged varchar(20),foreign key(Patient_ID) references patient(Patient_ID))");
					
					
					
					int rs1= stmnt1.executeUpdate();
						
					
						if(rs1>0) {
							//JOptionPane.showMessageDialog(null,"Successful");
							//label_1.setText("Successfully signed up. Login for go next step");
							
						}
						else {
							JOptionPane.showMessageDialog(null,"Successful");
						}
						
						
						
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		btnPatientAdmit.setBounds(174, 81, 130, 23);
		frame.getContentPane().add(btnPatientAdmit);
		
		JButton btnTreatment = new JButton("Treatment");
		btnTreatment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection1= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt1= (PreparedStatement) connection1.prepareStatement("CREATE TABLE treatment(T_ID int primary key AUTO_INCREMENT,Patient_ID int not null,Doctor_ID int not null,Disease varchar(20) not null,Cost int not null,Total_pay int not null,Due int,foreign key(Patient_ID) references patient(Patient_ID),foreign key(Doctor_ID) references doctor(Doctor_ID))");
					
					
					
					int rs1= stmnt1.executeUpdate();
						
					
						if(rs1>0) {
							//JOptionPane.showMessageDialog(null,"Successful");
							//label_1.setText("Successfully signed up. Login for go next step");
							
						}
						else {
							JOptionPane.showMessageDialog(null,"Successful");
						}
						
						
						
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		btnTreatment.setBounds(174, 149, 130, 23);
		frame.getContentPane().add(btnTreatment);
		
		JButton btnWard = new JButton("Ward");
		btnWard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection1= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt1= (PreparedStatement) connection1.prepareStatement("CREATE TABLE ward(Ward_no int not null,Bed_no int not null,Status varchar(20) default 'empty')");
					
					
					
					int rs1= stmnt1.executeUpdate();
						
					
						if(rs1>0) {
							//JOptionPane.showMessageDialog(null,"Successful");
							//label_1.setText("Successfully signed up. Login for go next step");
							
						}
						else {
							JOptionPane.showMessageDialog(null,"Successful");
						}
						
						
						
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		btnWard.setBounds(174, 183, 130, 23);
		frame.getContentPane().add(btnWard);
		
		JButton btnCabin = new JButton("Cabin");
		btnCabin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection1= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt1= (PreparedStatement) connection1.prepareStatement("CREATE TABLE cabin(Cabin_no int primary key,Status varchar(20) default 'empty')");
					
					
					
					int rs1= stmnt1.executeUpdate();
						
					
						if(rs1>0) {
							//JOptionPane.showMessageDialog(null,"Successful");
							//label_1.setText("Successfully signed up. Login for go next step");
							
						}
						else {
							JOptionPane.showMessageDialog(null,"Successful");
						}
						
						
						
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		btnCabin.setBounds(174, 217, 130, 23);
		frame.getContentPane().add(btnCabin);
		
		JButton btnAppoinment = new JButton("Appoinment");
		btnAppoinment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection1= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt1= (PreparedStatement) connection1.prepareStatement("CREATE TABLE appoinment(Appoinment_no int primary key AUTO_INCREMENT,Doctor_ID int not null,Patient_ID int not null,Appoinment_date varchar(20),foreign key(Doctor_ID) references doctor(Doctor_ID),foreign key(Patient_ID) references patient(Patient_ID))");
					
					
					
					int rs1= stmnt1.executeUpdate();
						
					
						if(rs1>0) {
							//JOptionPane.showMessageDialog(null,"Successful");
							//label_1.setText("Successfully signed up. Login for go next step");
							
						}
						else {
							JOptionPane.showMessageDialog(null,"Successful");
						}
						
						
						
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		btnAppoinment.setBounds(174, 285, 130, 23);
		frame.getContentPane().add(btnAppoinment);
		
		JButton btnDoctorChamber = new JButton("Doctor Chamber");
		btnDoctorChamber.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection1= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt1= (PreparedStatement) connection1.prepareStatement("CREATE TABLE doctor_chamber(Room_no int primary key AUTO_INCREMENT,Floor_no int not null,Doctor_ID int not null,foreign key(Doctor_ID) references doctor(Doctor_ID))");
					
					
					
					int rs1= stmnt1.executeUpdate();
						
					
						if(rs1>0) {
							//JOptionPane.showMessageDialog(null,"Successful");
							//label_1.setText("Successfully signed up. Login for go next step");
							
						}
						else {
							JOptionPane.showMessageDialog(null,"Successful");
						}
						
						
						
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		btnDoctorChamber.setBounds(314, 81, 130, 23);
		frame.getContentPane().add(btnDoctorChamber);
		
		JButton btnPatientAdmitCabin = new JButton("Patient Admit Cabin");
		btnPatientAdmitCabin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection1= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt1= (PreparedStatement) connection1.prepareStatement("CREATE TABLE patient_admit_cabin(Patient_ID int primary key,cabin_no int not null,Date_of_admit varchar(20) not null,Date_of_discharged varchar(20),foreign key(Patient_ID) references patient(Patient_ID),foreign key(Cabin_no) references cabin(Cabin_no))");
					
					
					
					int rs1= stmnt1.executeUpdate();
						
					
						if(rs1>0) {
							//JOptionPane.showMessageDialog(null,"Successful");
							//label_1.setText("Successfully signed up. Login for go next step");
							
						}
						else {
							JOptionPane.showMessageDialog(null,"Successful");
						}
						
						
						
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		btnPatientAdmitCabin.setBounds(314, 149, 130, 23);
		frame.getContentPane().add(btnPatientAdmitCabin);
		
		JButton btnBillTable = new JButton("Bill Table");
		btnBillTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection1= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt1= (PreparedStatement) connection1.prepareStatement("CREATE TABLE Bill(Patient_ID int primary key,Description varchar(50) not null,Cost int not null,foreign key(Patient_ID) references patient(Patient_ID))");
					
					
					
					int rs1= stmnt1.executeUpdate();
						
					
						if(rs1>0) {
							//JOptionPane.showMessageDialog(null,"Successful");
							//label_1.setText("Successfully signed up. Login for go next step");
							
						}
						else {
							JOptionPane.showMessageDialog(null,"Successful");
						}
						
						
						
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
				
			
		});
		btnBillTable.setBounds(60, 149, 89, 23);
		frame.getContentPane().add(btnBillTable);
	}
}
