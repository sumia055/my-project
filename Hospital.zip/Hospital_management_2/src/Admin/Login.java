package Admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;

import Patient.Patient_bill;

import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Login {

	private JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;
	private JLabel lblLogin;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 589, 396);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(139, 119, 264, 43);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(139, 193, 264, 43);
		frame.getContentPane().add(passwordField);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(10, 119, 119, 43);
		frame.getContentPane().add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(10, 193, 119, 43);
		frame.getContentPane().add(lblPassword);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
					Statement stmnt= con.createStatement();
					String sql="Select * from logindata where Username='"+textField.getText()+"'and Password= '"+passwordField.getText().toString()+"'"; 
					ResultSet rs= stmnt.executeQuery(sql);
					if(rs.next()) {
						Admin_option window = new Admin_option();
						frame.setVisible(false);
						window.main(null);
						}
						
					else {
						
						JOptionPane.showMessageDialog(null,"Failed");}
					con.close();
					
					
				
			}catch(Exception f) {System.out.println(f);}
			}
		});
		btnLogin.setBounds(139, 278, 89, 23);
		frame.getContentPane().add(btnLogin);
		
		lblLogin = new JLabel("Login");
		lblLogin.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblLogin.setBounds(10, 32, 252, 26);
		frame.getContentPane().add(lblLogin);
	}
}
