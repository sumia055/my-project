package Admin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;

public class Add_doctor {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JComboBox comboBox;
	private JButton btnNewButton;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_doctor window = new Add_doctor();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Add_doctor() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 473, 551);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt= (PreparedStatement) connection.prepareStatement("INSERT INTO doctor(Name,Address,Phone_no,Sex,Time_Sedule,Designation)VALUES(?,?,?,?,?,?)");
					//stmnt.setString(1,textField_1.getText());
					stmnt.setString(1,textField.getText());
					//stmnt.setString(3,textField_3.getText());
					stmnt.setString(2,textField_1.getText());
					stmnt.setString(3,textField_2.getText());
					stmnt.setString(4,comboBox.getSelectedItem().toString());
					stmnt.setString(5,textField_3.getText());
					stmnt.setString(6,textField_4.getText());
					
					
					int rs= stmnt.executeUpdate();
						
					
						if(rs>0) {
							JOptionPane.showMessageDialog(null,"Successfully Added");
							//label_1.setText("Successfully signed up. Login for go next step");
						}
						else {
							JOptionPane.showMessageDialog(null,"Failed");
						}
						
						
						stmnt.close();
						connection.close();
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					JOptionPane.showMessageDialog(null,"Something Went Wrong");
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					JOptionPane.showMessageDialog(null,"Something Went Wrong");
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
				textField.setText(null);
				textField_1.setText(null);
				textField_2.setText(null);
				textField_3.setText(null);
				textField_4.setText(null);
				//textField_5.setText(null);
		
				
			}
		});
		btnAdd.setBounds(124, 407, 89, 23);
		frame.getContentPane().add(btnAdd);
		
		textField = new JTextField();
		textField.setBounds(124, 113, 223, 38);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(124, 162, 223, 38);
		frame.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(124, 211, 223, 38);
		frame.getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(124, 309, 223, 38);
		frame.getContentPane().add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(124, 358, 223, 38);
		frame.getContentPane().add(textField_4);
		
		JLabel lblName = new JLabel("Name*");
		lblName.setBounds(28, 119, 73, 26);
		frame.getContentPane().add(lblName);
		
		JLabel lblAddress = new JLabel("Address*");
		lblAddress.setBounds(28, 168, 73, 26);
		frame.getContentPane().add(lblAddress);
		
		JLabel lblNewLabel = new JLabel("Phone No.*");
		lblNewLabel.setBounds(28, 217, 73, 26);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNid = new JLabel("Time Sedule*");
		lblNid.setBounds(28, 321, 73, 26);
		frame.getContentPane().add(lblNid);
		
		JLabel lblDutyTime = new JLabel("Designation*");
		lblDutyTime.setBounds(28, 370, 73, 26);
		frame.getContentPane().add(lblDutyTime);
		
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female"}));
		comboBox.setBounds(124, 260, 223, 38);
		frame.getContentPane().add(comboBox);
		
		JLabel lblSex = new JLabel("Sex*");
		lblSex.setBounds(28, 272, 73, 26);
		frame.getContentPane().add(lblSex);
		
		btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnNewButton.setBounds(10, 476, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblAddDoctor = new JLabel("Add Doctor");
		lblAddDoctor.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAddDoctor.setBounds(28, 28, 252, 26);
		frame.getContentPane().add(lblAddDoctor);
	}
}
