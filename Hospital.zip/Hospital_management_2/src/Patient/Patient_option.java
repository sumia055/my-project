package Patient;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;

public class Patient_option {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Patient_option window = new Patient_option();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Patient_option() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 309, 393);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnAddPatientRecord = new JButton("Appoinment");
		btnAddPatientRecord.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Add_appoinment window = new Add_appoinment();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnAddPatientRecord.setBounds(61, 138, 162, 28);
		frame.getContentPane().add(btnAddPatientRecord);
		
		JButton btnAddAppoinment = new JButton("All Doctor List");
		btnAddAppoinment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				All_doctors window = new All_doctors();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnAddAppoinment.setBounds(61, 177, 162, 28);
		frame.getContentPane().add(btnAddAppoinment);
		
		JButton btnAllAppoinments = new JButton("Bills");
		btnAllAppoinments.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient_bill window = new Patient_bill();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnAllAppoinments.setBounds(61, 216, 162, 28);
		frame.getContentPane().add(btnAllAppoinments);
		
		JLabel lblOption = new JLabel("Option");
		lblOption.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblOption.setBounds(22, 32, 162, 37);
		frame.getContentPane().add(lblOption);
	}
}
