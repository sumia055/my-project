package Patient;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;

public class Add_appoinment {

	private JFrame frame;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTable table_1;
	private JTextField textField_4;
	private JTextField textField;
	private JLabel lblDate;
	private JButton btnBack;
	private JLabel lblAddAppoinment;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_appoinment window = new Add_appoinment();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Add_appoinment() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 561, 462);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(109, 95, 208, 33);
		frame.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(109, 139, 208, 33);
		frame.getContentPane().add(textField_2);
		
		JLabel lblDoctorId = new JLabel("Doctor ID");
		lblDoctorId.setBounds(10, 95, 89, 33);
		frame.getContentPane().add(lblDoctorId);
		
		JLabel lblPatientId = new JLabel("Patient ID");
		lblPatientId.setBounds(10, 139, 89, 33);
		frame.getContentPane().add(lblPatientId);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					PreparedStatement stmnt= (PreparedStatement) connection.prepareStatement("INSERT INTO appoinment(Doctor_ID,Patient_ID,Appoinment_date)VALUES(?,?,?)");
					
					stmnt.setString(1,textField_1.getText());
					stmnt.setString(2,textField_2.getText());
					stmnt.setString(3,textField.getText());
					
					
					
					int rs= stmnt.executeUpdate();
						
					
						if(rs>0) {
							JOptionPane.showMessageDialog(null,"Successfully Added");
							//label_1.setText("Successfully signed up. Login for go next step");
						}
						else {
							JOptionPane.showMessageDialog(null,"Failed");
						}
						
						
						stmnt.close();
						connection.close();
						
					
					
					
								
					
					
					
					
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
				textField.setText(null);
				textField_1.setText(null);
				textField_2.setText(null);
				
			}
		});
		btnNewButton.setBounds(109, 234, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(327, 95, 180, 143);
		frame.getContentPane().add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i= table_1.getSelectedRow();
				TableModel model = table_1.getModel();
				textField_1.setText(model.getValueAt(i,0).toString());
			}
		});
		scrollPane_1.setViewportView(table_1);
		
		textField_4 = new JTextField();
		textField_4.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","");
					con.createStatement();
					
					
					PreparedStatement pst= con.prepareStatement("select Doctor_ID,Name from doctor where Doctor_ID='"+textField_4.getText()+"' or Name='"+textField_4.getText()+"'");
					ResultSet rs=pst.executeQuery("select Doctor_ID,Name from doctor where Doctor_ID='"+textField_4.getText()+"' or Name='"+textField_4.getText()+"'");
					
					ResultSetMetaData rsdata= rs.getMetaData();
					
					int columns= rsdata.getColumnCount();
					DefaultTableModel dtm= new DefaultTableModel();
					Vector columns_name= new Vector();
					Vector data_rows= new Vector();
					
					for(int i=1; i<=columns;i++) {
						columns_name.addElement(rsdata.getColumnName(i));
						
					}
					dtm.setColumnIdentifiers(columns_name);
					while(rs.next()) {
						data_rows= new Vector();
						for(int j=1;j<=columns;j++) {
							data_rows.addElement(rs.getString(j));
							
						}
						dtm.addRow(data_rows);
					}
					table_1.setModel(dtm);
				} catch (SQLException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				} catch (ClassNotFoundException f) {
					// TODO Auto-generated catch block
					f.printStackTrace();
				}
			}
		});
		textField_4.setColumns(10);
		textField_4.setBounds(412, 57, 95, 33);
		frame.getContentPane().add(textField_4);
		
		JLabel lblSearchDoctor = new JLabel("Search Doctor");
		lblSearchDoctor.setBounds(327, 57, 95, 33);
		frame.getContentPane().add(lblSearchDoctor);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(109, 183, 208, 33);
		frame.getContentPane().add(textField);
		
		lblDate = new JLabel("Date");
		lblDate.setBounds(10, 183, 89, 33);
		frame.getContentPane().add(lblDate);
		
		btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient_option window = new Patient_option();
				frame.setVisible(false);
				window.main(null);
			}
		});
		btnBack.setBounds(10, 388, 89, 23);
		frame.getContentPane().add(btnBack);
		
		lblAddAppoinment = new JLabel("Add Appoinment");
		lblAddAppoinment.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAddAppoinment.setBounds(10, 11, 252, 26);
		frame.getContentPane().add(lblAddAppoinment);
	}
}
